Thanks for downloading my Ticket Tracker Management System!

This was a project i had with the MSSA - Microsoft Software and Systems Academy at Embry Riddle Aeronautical University from 1 July to 10 November 2020.

This project taught me everything there  is to learn about SQL and SQLite injection databases, C# classes and object oriented programming, Business Logic and Data Logic layouts, password hashing and security, and tons of problem solving on the fly as I published this.

This took many countless nights and days to complete and I am extremely happy with the finished product.  

To access the program use 

Username: admin
Password: 123

All the username are in the admin page.  Just use the username for each persons password as well to access their dashboards


Enjoy!

JAMES B. SILCOTT
silcott.jb@outlook.com